@echo off
cd /d "%~dp0"
"runtime\python.exe" -B "app\launcher.py" 
if errorlevel 1 pause
