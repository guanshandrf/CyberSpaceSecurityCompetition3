"""Portable local demonstration. No application secrets are bundled."""
import argparse
from contextlib import asynccontextmanager
import getpass
import os
from pathlib import Path
import threading
import time
from urllib.request import urlopen
import webbrowser


def main():
    parser = argparse.ArgumentParser(description='AgentGuard Windows portable demonstration')
    parser.add_argument('--real-api', action='store_true')
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--port', type=int, default=18765)
    parser.add_argument('--data-dir', default='data')
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error('Port must be between 1024 and 65535')
    root = Path(__file__).resolve().parent.parent
    os.chdir(root)
    relative = Path(args.data_dir)
    if relative.is_absolute() or '..' in relative.parts:
        parser.error('Data directory must be inside this package')
    data = root / relative
    if not data.resolve().is_relative_to(root):
        parser.error('Data directory must be inside this package')
    os.environ['LANGSMITH_TRACING'] = 'false'
    os.environ['LANGCHAIN_TRACING_V2'] = 'false'
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    from fastapi import FastAPI
    from fastapi.staticfiles import StaticFiles
    from pydantic import SecretStr
    import uvicorn
    from agentguard_demo.api import create_app
    from agentguard_demo.settings import DemoSettings

    key = ''
    if args.real_api:
        key = os.environ.get('DEEPSEEK_API_KEY', '') or getpass.getpass('DeepSeek API Key (hidden, memory only): ')
        if not key.strip():
            parser.error('A non-empty Key is required for real API mode')
    settings = DemoSettings(
        enable_baseline=False, enable_protection=True,
        provider='fake', enable_model_selection=True,
        enable_real_api=args.real_api, api_key=SecretStr(key),
        sandbox_root=data, max_provider_calls=None,
        max_total_provider_calls=None, max_tokens=1024,
    )
    api = create_app(settings)

    @asynccontextmanager
    async def lifespan(app):
        async with api.router.lifespan_context(api):
            yield

    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
    app.mount('/api', api)
    app.mount('/', StaticFiles(directory=root/'web', html=True), name='web')
    address = f'http://127.0.0.1:{args.port}'
    print('AgentGuard protection ENABLED. Baseline DISABLED.', flush=True)
    print('Open: ' + address, flush=True)
    print('Model: offline Fake by default. Ctrl+C stops this server.', flush=True)
    if args.real_api:
        print('DeepSeek is available in the model selector; selecting it may incur API fees.', flush=True)
    if not args.no_browser:
        def open_when_ready():
            for _ in range(40):
                try:
                    with urlopen(address+'/api/health', timeout=1) as response:
                        if response.status == 200:
                            webbrowser.open(address)
                            return
                except OSError:
                    time.sleep(.25)
        threading.Thread(target=open_when_ready, daemon=True).start()
    uvicorn.run(app, host='127.0.0.1', port=args.port, workers=1, log_level='warning', access_log=False)


if __name__ == '__main__':
    main()
