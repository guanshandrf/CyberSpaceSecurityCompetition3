@echo off
cd /d "%~dp0"
"runtime\python.exe" -B "app\launcher.py" --real-api
if errorlevel 1 pause
