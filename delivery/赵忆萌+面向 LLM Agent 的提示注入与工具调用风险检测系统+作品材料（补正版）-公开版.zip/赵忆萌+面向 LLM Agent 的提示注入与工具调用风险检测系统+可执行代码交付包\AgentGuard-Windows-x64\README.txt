AgentGuard Windows 64位便携版

1. 将整个ZIP解压到可写目录，不要在压缩软件内直接启动（程序会在自身目录下创建 data，用于保存演示文件、审计与会话记录；放在只读目录会因无法创建 data 而退出）。
2. 双击 Start-AgentGuard.cmd，浏览器会打开 http://127.0.0.1:18765。
3. 默认离线Fake，无需Python、Node或API Key。Fake请使用场景中的工具命令；普通自然语言只回显。
4. 点击“创建演示场景”，依次体验文件访问权限、恶意文档注入、敏感信息脱敏。
5. 结束时在服务器窗口按Ctrl+C。data目录保存演示文件和本机审计，交付包初始不含历史数据。
6. 真实模型可双击 Start-DeepSeek.cmd，在控制台隐藏输入自己的Key，再在页面选择DeepSeek。Key仅驻留内存，勿发给评审或放入源码。真实API会计费；本次验收不调用。
7. 仅在Windows x64、本机回环地址使用；端口占用时执行 runtime\python.exe -B app\launcher.py --port 18766。
8. 原始工具引用和宿主机任意代码不在SDK接管范围。单进程运行，不对外网开放。

文件位置（解压后）
作品材料（补正版）/
├─ …+中国研究生网络安全创新大赛作品报告.pdf
├─ …+中国研究生网络安全创新大赛作品原创性声明.doc
├─ …+代码审计包.zip
├─ …+可执行代码交付包/
│   └─ AgentGuard-Windows-x64/          ← 本目录
│       ├─ Start-AgentGuard.cmd          ← 双击启动（离线演示）
│       ├─ Start-DeepSeek.cmd            ← 需要真实模型时双击
│       ├─ runtime\python.exe            ← 内置运行时，无需安装
│       └─ web\index.html                ← 界面文件
├─ …+交付与演示说明.pdf
└─ …+材料说明.txt

只需记住两件事：启动＝进入 可执行代码交付包\AgentGuard-Windows-x64\，双击 Start-AgentGuard.cmd；打开＝浏览器访问 http://127.0.0.1:18765。

运行环境与验证
- 适用系统：Windows 10/11 x64，已内置 Python 3.13.9 及全部依赖，无需安装任何运行环境，也无需联网。
- 已验证：解压后双击启动；文件访问权限场景中越权读取被 Gate 1 阻断（BLOCK / path.denied，工具未执行）；恶意文档注入场景中 Gate 2 阻断（BLOCK / result.instruction）；敏感信息场景中 Gate 2 脱敏（SANITIZE / result.redacted）。
- 若 Windows 提示“已阻止来自 Internet 的文件”或 SmartScreen 拦截：右键 ZIP → 属性 → 勾选“解除锁定”，再重新解压；也可直接用 7-Zip 解压。首次运行 python.exe 时选择“更多信息 → 仍要运行”。
- 同一 data 目录不要同时启动两个实例；如需多开，用 --data-dir 指定不同目录并更换端口。
- 详细设计、测试方法与证据见随附《作品报告》。

真实模型（DeepSeek）使用要点
1. 启动入口二选一：离线演示用 Start-AgentGuard.cmd；要使用真实 API（DeepSeek）必须双击 Start-DeepSeek.cmd。两者不要同时启动——默认都占用 18765 端口，同时启动会报 WinError 10048（地址已被占用）。切换入口时，先在原窗口按 Ctrl+C 停止，再启动另一个。
2. 双击 Start-DeepSeek.cmd 后，控制台提示“DeepSeek API Key (hidden, memory only):”。粘贴 Key 时屏幕不显示任何字符，属正常现象，粘贴后直接回车即可；Key 留空会报错并退出。
3. 控制台出现“DeepSeek is available in the model selector”即表示启动完成。此后该窗口不再接收键盘输入，按回车没有反应是正常的，请在浏览器中操作。
4. 切换模型后必须点击“使用所选模型新建对话”，原有会话保持原模型不变（会话创建后模型固定）。
5. 若页面下拉仍显示“后端未启用”，按 Ctrl+F5 强制刷新（前端缓存了旧的模型列表）。
